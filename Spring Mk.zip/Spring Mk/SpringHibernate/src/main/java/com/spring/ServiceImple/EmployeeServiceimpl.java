package com.spring.ServiceImple;

import org.springframework.stereotype.Service;

import com.spring.DaoImpl.EmployeeDaoImpl;
import com.spring.Model.Employee;
import com.spring.Service.EmployeeService;

@Service
public class EmployeeServiceimpl implements EmployeeService {

	private EmployeeDaoImpl daoImpl;

	public void addEmployee(Employee employee) {
		daoImpl.addEmployee(employee);

	}

	public void updateEmployee(Integer employeeid) {

		daoImpl.updateEmployee(employeeid);
	}

	public void deleteEmployee(Integer employeeid) {
		daoImpl.deleteEmployee(employeeid);

	}

}
