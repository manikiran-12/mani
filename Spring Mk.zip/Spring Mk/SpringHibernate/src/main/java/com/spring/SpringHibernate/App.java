package com.spring.SpringHibernate;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.Model.Employee;
import com.spring.ServiceImple.EmployeeServiceimpl;
import com.spring.utll.Config;

/**
 * Hello world!
 *
 */
public class App {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(Config.class);

		Employee employee = new Employee();
		employee.setEmployeeid(1);
		employee.setEmployeename("mani kiran");
		employee.setDesignation("Java");
		employee.setSalary(25000.00);
		EmployeeServiceimpl serviceImpl = applicationContext.getBean(EmployeeServiceimpl.class);
		serviceImpl.addEmployee(employee);
	}
}
