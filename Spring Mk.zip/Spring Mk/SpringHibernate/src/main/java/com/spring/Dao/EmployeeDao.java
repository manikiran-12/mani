package com.spring.Dao;

import com.spring.Model.Employee;

public interface EmployeeDao {
	
	public void addEmployee(Employee employee);
	
	public void updateEmployee(Integer employeeid);
	
	public void deleteEmployee(Integer employeeid);

}
