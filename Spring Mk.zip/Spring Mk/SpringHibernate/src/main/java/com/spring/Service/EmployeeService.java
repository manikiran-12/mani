package com.spring.Service;

import com.spring.Model.Employee;

public interface EmployeeService {
	
	public void addEmployee(Employee employee);

	public void updateEmployee(Integer employeeid);

	public void deleteEmployee(Integer employeeid);
}
