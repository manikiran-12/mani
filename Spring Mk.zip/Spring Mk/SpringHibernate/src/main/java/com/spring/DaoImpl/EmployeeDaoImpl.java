package com.spring.DaoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;

import com.mysql.cj.xdevapi.SessionFactory;
import com.spring.Dao.EmployeeDao;
import com.spring.Model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	private org.hibernate.SessionFactory sessionFactory;

	public void addEmployee(Employee employee) {
		sessionFactory.getCurrentSession().save(employee);
		System.out.println("Employee added successfully");

	}

	public void updateEmployee(Integer employeeid) {
		sessionFactory.getCurrentSession().saveOrUpdate(employeeid);

	}

	public void deleteEmployee(Integer employeeid) {
		sessionFactory.getCurrentSession().delete(employeeid);

	}

}
