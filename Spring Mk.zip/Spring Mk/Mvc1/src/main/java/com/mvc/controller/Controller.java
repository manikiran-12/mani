package com.mvc.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@org.springframework.stereotype.Controller

public class Controller {
	@RequestMapping(method = RequestMethod.GET, value = "/")
	public ModelAndView welcome() {
		return new ModelAndView("welcome", "Welcome", "Welcome to spring Mvc World");

	}
}
