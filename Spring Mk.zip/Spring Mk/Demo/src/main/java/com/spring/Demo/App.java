package com.spring.Demo;

/**
 * Hello world!
 *
 */
 
 class App 
{
	 final void m1() {
		 System.out.println("final");
	 }
}
 class App2 extends App{
	 void meth() {
		 System.out.println("welcome");
	 }
 

    public static void main( String[] args )
    {

    	App2 app2 = new App2();
    }
}
