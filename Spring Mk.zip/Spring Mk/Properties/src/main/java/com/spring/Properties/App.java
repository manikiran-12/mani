package com.spring.Properties;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.PropertySource;

/**
 * Hello world!
 *
 */

public class App 
{
	


	public static void main( String[] args )
    {
		
		
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(EmployeeConfig.class);
    	Service service = context.getBean(Service.class);
//    	employee.setEmpid(10);
//    	employee.setEmpname("Mani");
//    	System.out.println(employee.getEmpname()+" , "+employee.getEmpid() );
    	service.dispaly();
    	
    	
    
    }
}
