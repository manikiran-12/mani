package com.spring.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
@Component
@PropertySource(value = "classpath:/Properties/src/resources/java/Employee.properties")
public class Service {
	@Autowired
	private Environment environment;
	@Autowired
	private Employee employee;
	public void dispaly() {
		Employee employee2 = new Employee();
		String parseInt =environment.getProperty("empid");
		System.out.println(parseInt);
		int parseInt2 = Integer.parseInt(parseInt);
		
		Integer empid = employee2.setEmpid(parseInt2);
		System.out.println("Empid : "+empid);
	}
}
