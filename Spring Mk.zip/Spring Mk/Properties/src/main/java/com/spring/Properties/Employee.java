package com.spring.Properties;

import org.springframework.stereotype.Component;

@Component
public class Employee {

	private  Integer empid;
	
	private String empname;

	public Integer getEmpid() {
		return empid;
	}

	public Integer setEmpid(Integer empid) {
		return this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + "]";
	}
	
	
}
