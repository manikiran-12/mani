package com.mvc.Config;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {
	
	@RequestMapping("/register")
	public String student() {
		System.out.println("Hello");
		return "successman";
		
	}

}
//@RequestParam("sid") String id,@RequestParam("sname") String name,@RequestParam("semail") String email