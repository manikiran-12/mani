package com.spring.SpringJDBC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DbOperations {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void addStudent(Student student) {

		jdbcTemplate.update("insert into student values (?,?,?,?)", student.getSid(), student.getSname(),
				student.getCourse(), student.getFee());
	}
	public void deleteStudent(int id)
	{
		jdbcTemplate.update("DELETE from student where sid ="+id);
		System.out.println("deleted successfully");
	}
	public void updateStudent(int id) {
		jdbcTemplate.update("update student set sname='pranay',fee=1200.00 where sid="+id);
		System.out.println("updated successfully");
	}

}
