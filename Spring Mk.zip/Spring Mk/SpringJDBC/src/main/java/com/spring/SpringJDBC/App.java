package com.spring.SpringJDBC;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    private static final String JdbcTemplate = null;

	@SuppressWarnings("resource")
	public static void main( String[] args )
    {
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
    	Student student = new Student();
    	student.setSid(1);
    	student.setSname("Mani");
    	student.setCourse("java");
    	student.setFee(1000.00);
    	DbOperations dbOperations = context.getBean(DbOperations.class);
 	dbOperations.addStudent(student);
//      dbOperations.deleteStudent(1);
    	//dbOperations.updateStudent(1);
    	
    }
}
