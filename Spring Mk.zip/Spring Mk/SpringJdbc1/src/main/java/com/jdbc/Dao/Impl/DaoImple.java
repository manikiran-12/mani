package com.jdbc.Dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.jdbc.Dao.Dao;
import com.jdbc.Model.Student;

@Repository
public class DaoImple implements Dao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void addStudent(Student student) {

		jdbcTemplate.update("insert into student values(?,?,?)",student.getSid(),student.getSname(),student.getFees());
		System.out.println("Inserted successfully");

	}

	public void deleteStudent(Integer id) {
	
		jdbcTemplate.update("DELETE from student where sid="+id);
		System.out.println("Deleted successfully");
	}

	public List<Student> getStudents() {
	
		List<Student> list = jdbcTemplate.query("select * from student", new RowMapper<Student>() {

			public  Student mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				Student student = new  Student();
				
				List<Student> list = new ArrayList<Student>();
				
				while(rs.next()) {
		
				student.setSid(rs.getInt(1));
				student.setSname(rs.getString(2));
				student.setFees(rs.getDouble(3));
				
				list.add(student);
					
				}
				return (Student) list;
			}
			
		});
		
		return null;
	}

}
