package com.jdbc.util;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class DataSourceUtil {
    
	
	@Bean
	public DataSource datasource() {
		DriverManagerDataSource source = new DriverManagerDataSource();
		source.setDriverClassName("com.mysql.cj.jdbc.Driver");
		source.setUrl("jdbc,mysql://localhost:3306/mani");
		source.setUsername("root");
		source.setPassword("root");
		return source;
	}
	
}
