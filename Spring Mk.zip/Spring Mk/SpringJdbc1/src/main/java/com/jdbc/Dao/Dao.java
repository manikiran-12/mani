package com.jdbc.Dao;

import java.util.List;

import com.jdbc.Model.Student;

public interface Dao {
	
	public void addStudent(Student student);
	
	public void deleteStudent(Integer id);
	
	public List<Student> getStudents();

}
