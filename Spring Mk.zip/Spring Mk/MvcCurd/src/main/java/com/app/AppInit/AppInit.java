package com.app.AppInit;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

@Configuration
public class AppInit implements WebApplicationInitializer {

	@SuppressWarnings("resource")
	public void onStartup(ServletContext servletContext) throws ServletException {

		AnnotationConfigWebApplicationContext webApplicationContext = new AnnotationConfigWebApplicationContext();
		webApplicationContext.register(DispatcherServlet.class);
		servletContext.addListener(new ContextLoaderListener(webApplicationContext));
		Dynamic dynamic = servletContext.addServlet("dispatcherservlet",new DispatcherServlet(webApplicationContext));
		dynamic.setLoadOnStartup(1);
		dynamic.addMapping("/");
	}

}
