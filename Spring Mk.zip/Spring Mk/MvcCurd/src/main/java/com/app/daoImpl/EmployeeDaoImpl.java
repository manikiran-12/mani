package com.app.daoImpl;

import org.springframework.stereotype.Repository;

import com.app.dao.EmployeeDao;
import com.app.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	public Integer saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
	}

	public void deleteEmployee(Integer empid) {
		// TODO Auto-generated method stub
		
	}



}
