package com.app.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.EmployeeDao;
import com.app.model.Employee;
import com.app.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDao empdao;
	

	public Integer saveEmployee(Employee employee) {
		return empdao.saveEmployee(employee);
	}

	public void updateEmployee(Employee employee) {
		empdao.updateEmployee(employee);

	}

	public void deleteEmployee(Integer empid) {
		empdao.deleteEmployee(empid);
	}

}
