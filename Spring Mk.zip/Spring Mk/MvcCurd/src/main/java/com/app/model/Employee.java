package com.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "empid")
	private Integer empid;
	@Column(name = "employee_name")
	private String empname;
	@Column(name = "employee_pwd")
	private String emppwd;
	@Column(name = "employee_Gender")
	private String empgen;
	@Column(name = "employee_Address")
	private String empadd;
	@Column(name = "employee_Country")
	private String empcoun;

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", emppwd=" + emppwd + ", empgen=" + empgen
				+ ", empadd=" + empadd + ", empcoun=" + empcoun + "]";
	}

	public Integer getEmpid() {
		return empid;
	}

	public void setEmpid(Integer empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getEmppwd() {
		return emppwd;
	}

	public void setEmppwd(String emppwd) {
		this.emppwd = emppwd;
	}

	public String getEmpgen() {
		return empgen;
	}

	public void setEmpgen(String empgen) {
		this.empgen = empgen;
	}

	public String getEmpadd() {
		return empadd;
	}

	public void setEmpadd(String empadd) {
		this.empadd = empadd;
	}

	public String getEmpcoun() {
		return empcoun;
	}

	public void setEmpcoun(String empcoun) {
		this.empcoun = empcoun;
	}

}
