package com.app.AppController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/reg")
public class EmployeeController {
	
	@GetMapping
	public String saveEmployee() {
System.out.println("hello");
		return "register";
	}

}
