package com.app.service;

import com.app.model.Employee;

public interface EmployeeService {
	
	public Integer saveEmployee(Employee employee);
	
	public void updateEmployee(Employee employee);
	
	public void deleteEmployee(Integer empid);

}
