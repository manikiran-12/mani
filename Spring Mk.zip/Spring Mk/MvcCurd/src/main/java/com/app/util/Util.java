package com.app.util;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@EnableTransactionManagement
@PropertySource(value = { "classpath:dbconnection.properties", "classpath:hibernate.properties" })
public class Util {

	@Autowired
	private Environment environmemt;
	@Autowired
	private DataSource datasource;

	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(environmemt.getProperty("db.driverclass"));
		dataSource.setUrl(environmemt.getProperty("db.url"));
		dataSource.setUsername(environmemt.getProperty("db.username"));
		dataSource.setPassword(environmemt.getProperty("db.password"));
		return dataSource;

	}

	@Bean
	public HibernateTransactionManager transactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(bean().getObject());
		return transactionManager;
	}

	@Bean

	public LocalSessionFactoryBean bean() {
		LocalSessionFactoryBean factoryBean = new LocalSessionFactoryBean();
		factoryBean.setDataSource(datasource);
		factoryBean.setHibernateProperties(properties());
		return factoryBean;

	}

	private Properties properties() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", environmemt.getProperty("hb.dialect"));
		properties.put("hibernate.show_sql", environmemt.getProperty("showsql"));
		properties.put("hibernate.format_sql", environmemt.getProperty("formatsql"));
		properties.put("hibernate.hb2ddl.auto", environmemt.getProperty("ddlauto"));

		return properties;
	}
	

}
