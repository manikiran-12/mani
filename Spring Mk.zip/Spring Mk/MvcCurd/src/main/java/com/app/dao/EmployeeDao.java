package com.app.dao;

import com.app.model.Employee;

public interface EmployeeDao {
	
	public Integer saveEmployee(Employee employee);
	
	public void updateEmployee(Employee employee);
	
	public void deleteEmployee(Integer empid);

}
