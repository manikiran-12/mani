package com.curd.Dao;

import com.curd.Model.Employee;

public interface EmployeeDao {
	
	public void addEmployee(Employee employee);
	
	public void deleteEmployee(Integer employeeid);

}
