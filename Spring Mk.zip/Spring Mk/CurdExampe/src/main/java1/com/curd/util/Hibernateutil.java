package com.curd.util;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@PropertySource(value = {"classpath:dbconnection.properties","classpath:hibernate.properties"})

public class Hibernateutil {
	
	@Autowired
	private Environment environment;
	@Autowired
	private DataSource datasource;
	
	@Bean
	public LocalSessionFactoryBean sessionFactoryBean() {
		LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
		sessionFactoryBean.setDataSource(datasource);
		sessionFactoryBean.setHibernateProperties(properties());
		return null;
	
	}
	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(environment.getProperty("db.driverclass"));
		dataSource.setUrl(environment.getProperty("db.url"));
		dataSource.setUsername("db.username");
		dataSource.setPassword(environment.getProperty("db.password"));
		return dataSource;
	}
	
	@Bean
	public HibernateTransactionManager transactionManager(org.hibernate.SessionFactory sessionFactory) {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory);
		return transactionManager;
	
	}
	
	public Properties properties() {
		Properties properties = new Properties();
		properties.setProperty("hb.dialect", environment.getRequiredProperty("hb.dialect"));
		properties.setProperty("hb.showsql", environment.getRequiredProperty("hb.showsql"));
		properties.setProperty("hb.formatesql", environment.getRequiredProperty("hb.formatesql"));
		properties.setProperty("hbm2ddl", environment.getRequiredProperty("hbm2ddl"));
		return properties;
		
	}

}
