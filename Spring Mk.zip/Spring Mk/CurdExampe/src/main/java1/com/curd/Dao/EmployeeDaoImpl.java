/**
 * 
 */
package com.curd.Dao;

import org.springframework.stereotype.Repository;

import com.curd.Model.Employee;

/**
 * @author mk19439
 *
 */
@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	public void addEmployee(Employee employee) {
		

	}

	public void deleteEmployee(Integer employeeid) {
		

	}

}
