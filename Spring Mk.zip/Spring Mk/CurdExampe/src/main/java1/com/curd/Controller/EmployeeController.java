package com.curd.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.curd.Model.Employee;
import com.curd.Service.EmployeeServiceImpl;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeServiceImpl serviceImpl;

	@RequestMapping("/welcome")
	
	public String addEmployee(Model model)
	{
	
		model.addAttribute("employee1", new Employee());
		
		return "Add";
		
	}
	
	
	@RequestMapping("/welcome1")
	public String addEmployee1(@ModelAttribute("employee1") Employee employee)
	{
	
		
		
		return "success";
		
	}
}
