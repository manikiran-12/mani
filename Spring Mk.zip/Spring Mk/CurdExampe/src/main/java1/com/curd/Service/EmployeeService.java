package com.curd.Service;

import com.curd.Model.Employee;

public interface EmployeeService {
	
	public void addEmployee(Employee employee);
	
	public void deleteEmployee(Integer employeeid);

}
