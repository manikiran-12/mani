package com.curd.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curd.Dao.EmployeeDaoImpl;
import com.curd.Model.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDaoImpl daoImpl;

	public void addEmployee(Employee employee) {
		
		daoImpl.addEmployee(employee);

	}

	public void deleteEmployee(Integer employeeid) {

		daoImpl.deleteEmployee(employeeid);
	}

}
