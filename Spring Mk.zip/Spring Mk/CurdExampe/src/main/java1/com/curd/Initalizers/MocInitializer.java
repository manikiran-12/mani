package com.curd.Initalizers;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.web.WebApplicationInitializer;

public class MocInitializer implements WebApplicationInitializer	 {
	
	@Override
		public void onStartup(ServletContext servletContext) {
		
			AnnotationConfigWebApplicationContext container = new AnnotationConfigWebApplicationContext();
			container.register(MOCUtil.class);
			
			DispatcherServlet dispatcherServlet = new DispatcherServlet(container);
			
			Dynamic dynamic = servletContext.addServlet("ds", dispatcherServlet);
			dynamic.setLoadOnStartup(4);
			dynamic.addMapping("/");
		

	}

		public void onStartup1(ServletContext servletContext) throws ServletException {
			// TODO Auto-generated method stub
			
		}


}
