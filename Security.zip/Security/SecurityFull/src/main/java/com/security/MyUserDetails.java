package com.security;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public class MyUserDetails implements org.springframework.security.core.userdetails.UserDetails {

	private String userName;
    private String password;

    private List<GrantedAuthority> authorities;

public MyUserDetails() {
	
		super();
		System.out.println("5");
	}
	
	
	public MyUserDetails(User user) {
        this.userName = user.getUsername();
        this.password = user.getPassword();
    	System.out.println("4");
       
        this.authorities = Arrays.stream(user.getRole().split(","))
                    .map(SimpleGrantedAuthority::new)
                    .collect(Collectors.toList());
        
        System.out.println("4+1");
    }

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		System.out.println("6");
		return authorities;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		System.out.println("7");
		return password;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		System.out.println("8");

		return userName;
	
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

}
