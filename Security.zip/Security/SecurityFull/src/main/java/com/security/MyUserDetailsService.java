package com.security;

import javax.naming.AuthenticationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class MyUserDetailsService implements UserDetailsService {
	@Autowired
	private UserDao userdao;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		MyUserDetails myUserDetails2=null;
		
		System.out.println( username);

		User user = userdao.findByUsername(username);
		System.out.println("1");
		if(user!=null) {
			myUserDetails2 = new MyUserDetails(user);
			
			System.out.println("2");
		}
			else {
				throw new AuthenticationException("username not found") {

					/**
					 * 
					 */
					private static final long serialVersionUID = 1L;
				};
			}
		System.out.println("3");
		
			
			
			
		
		return myUserDetails2;
			
		
		
	

	}

}
