package com.security.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.security.Dao.UserDao;
import com.security.model.User;

@Controller
public class UserController {
	@Autowired
	private UserDao userdao;

	@GetMapping("/")
	public String registerpage() {
		return "register";
	}

	@GetMapping("/login1")
	public String login(@ModelAttribute("user") User user) {
		userdao.save(user);
		return "login1";

	}

	@GetMapping("/details")
	public User details(@ModelAttribute("user") User user) {
		
	

	}

	
	}

