package com.security.JWT;

import java.io.Serializable;
import java.sql.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class JwtTokenUtil implements Serializable {

	private static final long Token_validate = 5 * 60 * 60;

	@Value("${jwt.secret}")
	private String secret;

	public String getUsernamFromToken(String token) {
		return getClaimFromToken(token, Claims::getSubject);
	}

	public Date getExpirationDateFromToken(String token) {
		return (Date) getClaimFromToken(token, Claims::getExpiration);
	}

	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResoler) {
		Claims allClaimsFromToken = getAllClaimsFromToken(token);
		return claimsResoler.apply(allClaimsFromToken);
	}

	private Claims getAllClaimsFromToken(String token) {
		return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
	}

	private Boolean isTokenExpired(String token) {
		Date expirationDateFromToken = getExpirationDateFromToken(token);
		return expirationDateFromToken.before(new java.util.Date());
	}

	public String generateToken(UserDetails userdetails) {
		Map<String, Object> claims = new HashMap<String, Object>();
		return doGenerateToken(claims, userdetails.getUsername());
	}

	private String doGenerateToken(Map<String, Object> claims,String subject) {
		return Jwts.builder().setClaims(claims).setSubject(subject)
				.setIssuedAt(new java.util.Date(System.currentTimeMillis()))
				.setExpiration(new java.util.Date(System.currentTimeMillis()+Token_validate*1000))
				.signWith(SignatureAlgorithm.HS256, secret).compact();
	}
	public Boolean validateToken(String token, UserDetails userDetails) {
		final String username = getUsernamFromToken(token);
		return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
	}
}
