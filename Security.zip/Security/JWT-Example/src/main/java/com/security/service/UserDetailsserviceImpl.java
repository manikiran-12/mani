package com.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.security.dao.UserRepository;
import com.security.model.User;
import com.security.model.UserDetailsimpl;

public class UserDetailsserviceImpl implements UserDetailsService  {
	@Autowired
	UserRepository userepo;

	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		 User user = userepo.findByUsername(username);
		 if(user!=null) {
			 
			 return new UserDetailsimpl(user);			 
		 }
		 
		throw new UsernameNotFoundException("User Not found");
		
	}

}
