package com.dss;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class TestHash1 {

	public static void main(String[] args) {
		
		HashMap<Integer, String> h = new HashMap<Integer,String>();
		h.put(1, "Mani");
		h.put(2, "Srikanth");
		h.put(3, "venky");
		h.put(4, "Ravi");
		System.out.println(h);
		
		Set<Integer> s =h.keySet();
		System.out.println(s);
		
		Collection<String> c = h.values();
		System.out.println(c);
		
		Set<Entry<Integer, String>> ss = h.entrySet();
		for (Entry<Integer, String> entry : ss) {
			System.out.println(entry);
			
		}
	}

}
