package com.dss;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class EmpStuTest {
	public static void main(String[] args) {

		HashMap<Emp, Student> es = new HashMap<Emp, Student>();
		es.put(new Emp(11, "Mani"), new Student(1, "Santosh"));
		es.put(new Emp(22, "Sanvika"), new Student(2, "ravi"));
		es.put(new Emp(33, "pradeep"), new Student(3, "nithya"));
		System.out.println("Employee Details:");
		System.out.println("-------------------------");
		Set<Emp> se = es.keySet();

		Iterator<Emp> e = se.iterator();
		while (e.hasNext()) {
			Emp e1 = e.next();
			System.out.println(e1.eid + " " + e1.ename);
		}
		System.out.println("-------------------------");

		System.out.println("Student Details:");
		System.out.println("-------------------------");
		for (Student s : es.values())
			
		{
			System.out.println(s.sid+" "+s.sname);
			
		}

	}

}

