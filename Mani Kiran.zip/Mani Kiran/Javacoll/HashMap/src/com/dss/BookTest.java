package com.dss;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

public class BookTest {

	public static void main(String[] args) {

		LinkedHashMap<Integer, Book> ll = new LinkedHashMap<Integer, Book>();
		ll.put(1, new Book(111, "Java"));
		ll.put(2, new Book(222, "python"));
		ll.put(3, new Book(333, "Devops"));
		ll.put(4, new Book(444, "Php"));
		
		Set<Entry<Integer, Book>> ss = ll.entrySet();
		Iterator<Entry<Integer, Book>> itr = ss.iterator();
		while(itr.hasNext())
		{
			Entry<Integer, Book> e =  itr.next();
			Book b = e.getValue();
			if(b.bid==111)
				itr.remove();
			if(b.bname.equals("python"))
				itr.remove();
		}
		for (Entry<Integer, Book> entry : ss) {
			System.out.println(entry.getKey()+" " +entry.getValue().bid+" "+entry.getValue().bname);
			
		}
	}
	
}
