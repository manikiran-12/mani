package com.dss;

public class Book {
		int bid;
		String bname;
		public Book(int bid, String bname) {
			super();
			this.bid = bid;
			this.bname = bname;
		};
}
