package com.tss;

import java.util.SortedSet;
import java.util.TreeSet;

public class TreeTest {

	public static void main(String[] args) {

		
		TreeSet<Integer> ts = new TreeSet<Integer>();
		for(int i=1;i<=10;i++)
		{ts.add(i);
		}
		System.out.println(ts);
	
		
		SortedSet<Integer> tt = ts.tailSet(6);
		TreeSet<Integer> ts1 = new TreeSet<Integer>(tt);	
		System.out.println(ts1);
		
		SortedSet<Integer> tt1 = ts.headSet(5);
		TreeSet<Integer> ts2 = new TreeSet<>(tt1);
		System.out.println(ts2);
		SortedSet<Integer> tt2 = ts.subSet(5, 8);
		TreeSet<Integer> ts3 =new TreeSet<>(tt2);
		System.out.println(ts3);
		
	}

}
