package com.tss;

public class Mobile {
	String mname;
	Double price;
	Integer num;
	public Mobile(String mname, double price, Integer num) {
		super();
		this.mname = mname;
		this.price = price;
		this.num = num;
	}

}
