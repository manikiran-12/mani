package com.tss;

import java.util.Iterator;
import java.util.TreeSet;

public class Mtest {

	public static void main(String[] args) {
		TreeSet<Mobile> tm = new TreeSet<Mobile>(new Price());
		tm.add(new Mobile("Mi", 10000, 9848));
		tm.add(new Mobile("Nokia", 12000, 8849));
		tm.add(new Mobile("Samsung", 13000, 7722));
		tm.add(new Mobile("Lava", 9000,6655));
		
		Iterator<Mobile> m = tm.iterator();
		while(m.hasNext())
		{
			Mobile m1 = m.next();
			System.out.println(m1.mname+" "+m1.price+" "+m1.num);
		}
		

		

	}

}
