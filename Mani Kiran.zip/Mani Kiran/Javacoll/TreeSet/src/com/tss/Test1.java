package com.tss;

import java.util.Comparator;
import java.util.TreeSet;

public class Test1 {

	public static void main(String[] args) {
		TreeSet<Integer> t = new TreeSet<Integer>(new Test3());
		t.add(10);
		t.add(30);
		t.add(100);
		t.add(82);
		t.add(98);
		System.out.println(t);
	}}
		
		//To print Data in Descending order
		
		class Test2 implements Comparator<String>
		{

			@Override
			public int compare(String s1, String s2) {
				return -s1.compareTo(s2);
				
			}
			
		}
		
		
		//To Integer Data
		class Test3 implements Comparator<Integer>
		{

			@Override
			public int compare(Integer i1, Integer i2) {
				return i2.compareTo(i1);
			}
			
		}


