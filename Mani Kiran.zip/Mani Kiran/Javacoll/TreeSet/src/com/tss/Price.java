package com.tss;

import java.util.Comparator;

public class Price implements Comparator<Mobile> {

	@Override
	public int compare(Mobile p1, Mobile p2) {
		return -p1.price.compareTo(p2.price);
	}
	

}
