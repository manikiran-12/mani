package com.tss;

import java.util.Comparator;

public class Mname implements Comparator<Mobile>{

	@Override
	public int compare(Mobile s1, Mobile s2) {
		return -s1.mname.compareTo(s2.mname);
	}
	

}
