package com.dss;

public class Customer {
	Integer cid;
	String cname;
	public Customer(int cid, String cname) {
		super();
		this.cid = cid;
		this.cname = cname;
	}

}
