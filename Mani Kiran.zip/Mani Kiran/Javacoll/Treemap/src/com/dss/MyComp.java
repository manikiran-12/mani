package com.dss;

import java.util.Comparator;

public class MyComp implements Comparator<Integer>{

	@Override
	public int compare(Integer i1, Integer i2) {
		// TODO Auto-generated method stub
		return -i1.compareTo(i2);
	}
	

}
