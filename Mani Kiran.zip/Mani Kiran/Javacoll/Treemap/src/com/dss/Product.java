package com.dss;

public class Product {
	Integer pid;
	String pname;
	public Product(int pid, String pname) {
		super();
		this.pid = pid;
		this.pname = pname;
	}

}
