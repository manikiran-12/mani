package com.dss;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

public class TreeEx {

	public static void main(String[] args) {
		try
		{
		TreeMap<Product, Customer> t = new TreeMap<Product,Customer>();
		t.put(new Product(10000, "Pen"), new Customer(111, "Bharath"));
		t.put(new Product(25, "Bottole"), new Customer(333, "Vamshi"));
		t.put(new Product(1000, "Mobile"),new Customer(222, "Kiran"));
		
		Set<Product> p = t.keySet();
		Iterator<Product> p1 = p.iterator();
		while(p1.hasNext())
		{
			Product p2 = p1.next();
			System.out.println(p2.pname+" "+p2.pid);
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	
			
			
		}
		
	}


