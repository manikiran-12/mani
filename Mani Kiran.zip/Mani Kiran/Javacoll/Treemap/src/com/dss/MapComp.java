package com.dss;

import java.util.TreeMap;

public class MapComp {

	public static void main(String[] args) {
		
		TreeMap<Integer, String> t = new TreeMap<Integer,String>(new MyComp1()) ;
		
		t.put(1, "Mani");
		t.put(5, "Vamshi");
		t.put(3, "Bharath");
		t.put(4,"Sai");
		System.out.println(t);

	}
		

}
