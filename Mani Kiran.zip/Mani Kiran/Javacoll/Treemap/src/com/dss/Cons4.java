package com.dss;

import java.util.TreeMap;

public class Cons4 {

	public static void main(String[] args) {
		
		TreeMap<Integer, String> t1 = new TreeMap<Integer,String>(new MyComp());
		t1.put(1, "Mani");
		t1.put(5, "Ravi");
		t1.put(8, "Sandhya");
		t1.put(3, "Aruna");
		t1.put(2, "Chandu");
		System.out.println(t1);
		

	}

}
