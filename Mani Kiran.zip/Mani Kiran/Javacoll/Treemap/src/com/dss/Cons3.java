package com.dss;

import java.util.SortedMap;
import java.util.TreeMap;

public class Cons3 {

	public static void main(String[] args) {
		
		TreeMap<Integer, String> t1 = new TreeMap<Integer,String>();
		t1.put(1, "java");
		t1.put(50, "java");
		t1.put(30, "java");
		t1.put(40, "java");
		t1.put(60, "java");
		System.out.println(t1);
		SortedMap<Integer, String> t2 = t1.subMap(30, 60);
		TreeMap<Integer, String> m2= new TreeMap<Integer,String>(t2);
		System.out.println(m2);
		
		SortedMap<Integer, String>t3 = t1.tailMap(50);
		TreeMap<Integer, String> m3= new TreeMap<Integer,String>(t3);
		System.out.println(m3);
		
		
		SortedMap<Integer, String> t4 = t1.headMap(30);
		TreeMap<Integer, String> m4= new TreeMap<Integer,String>(t4);
		System.out.println(m4);

	}

}
