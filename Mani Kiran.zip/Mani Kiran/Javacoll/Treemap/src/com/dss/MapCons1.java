package com.dss;

import java.util.TreeMap;

public class MapCons1 {

	public static void main(String[] args) {
		
		TreeMap<String, Integer> t = new TreeMap<String,Integer>();
		t.put("Mani", 2);
		t.put("Abi",1);
		t.put("Bharath",5);
		t.put("Harsha", 4);
		
		TreeMap<String, Integer> t2 = new TreeMap<String,Integer>(t);
		t2.put("Santosh", 3);
		System.out.println(t2);
		
		
		TreeMap<String, Integer> m1 = new TreeMap<String,Integer>();
		
		m1.put("Java", 1);
		TreeMap<String, Integer> m2= new TreeMap<String,Integer>();
		m2.put("Python", 5);
		TreeMap<String, Integer> m3 = new TreeMap<String,Integer>();
		m3.put("Devops", 4);
		m3.putAll(m2);
		m3.putAll(m1);
		System.out.println(m3);
	
	
	}

}
