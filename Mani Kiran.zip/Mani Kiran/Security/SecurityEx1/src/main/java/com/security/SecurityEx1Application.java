package com.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityEx1Application {

	public static void main(String[] args) {
		SpringApplication.run(SecurityEx1Application.class, args);
	}

}
