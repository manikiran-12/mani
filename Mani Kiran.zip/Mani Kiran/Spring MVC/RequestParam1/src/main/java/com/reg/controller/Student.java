package com.reg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Student {
	@RequestMapping(method = RequestMethod.POST,value = "/register")
	public ModelAndView register(@RequestParam("sname") String sname,@RequestParam("mobile") String mobile,@RequestParam("email") String email) {
		System.out.println(sname);
		return new ModelAndView("success","successmsg","Name : "+sname+"<br> Mobile Number : "+mobile+"<br> Email : "+email);
		
	}

}
