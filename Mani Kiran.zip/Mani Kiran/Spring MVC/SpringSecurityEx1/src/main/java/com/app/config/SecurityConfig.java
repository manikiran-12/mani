package com.app.config;

public class SecurityConfig {

}
