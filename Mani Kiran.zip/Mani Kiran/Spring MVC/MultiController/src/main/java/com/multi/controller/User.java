package com.multi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class User {

	@RequestMapping(value = "/list")
	
	public String userlist() {
		return "userlist";
	}
	@RequestMapping(value = "/save")
	public ModelAndView saveUser(User user) {
		return new ModelAndView("save","usermsg","This is user save page");
	}
}
