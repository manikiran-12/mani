package com.redirect.Dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.redirect.model.User;

@Repository
public class UserDao {
	List<User> list = new ArrayList<User>();

	public List<User> listuser() {

		list.add(new User("Mani Kiran", "manikiran@gmail.com", 24));
		list.add(new User("Pranay", "prany@gmail.com", 24));
		list.add(new User("Nagarjuna", "nagarjuna@gmail.com", 25));
		return list;

	}

	public void createuser(User user) {
		list.add(user);
	}
}
