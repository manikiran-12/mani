package com.redirect.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.redirect.model.User;
import com.redirect.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService service;

	@RequestMapping(value = "/",method = RequestMethod.GET)
	public String register(Model model) {
		model.addAttribute("msg", "Registration Page");
		return "register";
	}
	@RequestMapping(value = "/register")
	public String adduser(@RequestParam("username") String username,@RequestParam("email") String email,@RequestParam("age") int age) {
		User user = new User(username, email, age);
		service.createuser(user);
		return "redirect:/userlist";
		
	}
	
	@RequestMapping(value = "/userlist",method = RequestMethod.GET)
	public ModelAndView listuser(@RequestParam("username") String username,@RequestParam("email") String email,@RequestParam("age") int age) {
		System.out.println(username);
		ModelAndView modelAndView = new ModelAndView("userlist");
		List<User> listuser = service.listuser();
		modelAndView.addObject("listuser");
		return modelAndView;
		
	}
}

