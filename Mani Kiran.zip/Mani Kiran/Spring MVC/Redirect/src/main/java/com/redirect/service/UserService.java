package com.redirect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redirect.model.User;

@Service
public class UserService {
	@Autowired
	private UserService service;

	public List<User> listuser() {
		return service.listuser();
	}

	public void createuser(User user) {
		service.createuser(user);
	}
}
