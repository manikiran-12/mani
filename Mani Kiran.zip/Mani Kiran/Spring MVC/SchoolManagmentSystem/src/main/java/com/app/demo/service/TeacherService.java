package com.app.demo.service;

import java.util.List;
import java.util.Optional;

import com.app.demo.models.Student;
import com.app.demo.models.Teacher;

public interface TeacherService {
	
	void addTeacher(Teacher teacher);

	String deleteTeacher(int id);
	
	Teacher findById(int id);

	List<Teacher> findAll();

	

}
