package com.app.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.app.demo.models.Student;

@Repository
@EnableJpaRepositories
public interface StudentDao extends JpaRepository<Student,Integer> {

	
	

}
