package com.app.demo.service;

import java.util.List;

import com.app.demo.models.Student;

public interface Studentservice {

	void addStudent(Student student);

	String deleteStudent(int id);

	List<Student> findAll();
	
	Student findById(int id) throws Exception;
	
//	Student updateById(int id);

	//Student updateById(Student student);
	

	

}
