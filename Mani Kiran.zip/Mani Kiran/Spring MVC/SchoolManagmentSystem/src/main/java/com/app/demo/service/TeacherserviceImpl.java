package com.app.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.demo.dao.TeacherDao;
import com.app.demo.models.Student;
import com.app.demo.models.Teacher;

@Service
public class TeacherserviceImpl implements TeacherService {

	@Autowired
	private TeacherDao tdao;
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public void addTeacher(Teacher teacher) {
		teacher.setPassword(passwordEncoder.encode(teacher.getPassword()));
		tdao.save(teacher);

	}

	@Override
	public String deleteTeacher(int id) {

		if (tdao.existsById(id)) {
			tdao.deleteById(id);
			return "Teacher is Deleted SuccessFully";
		}
		return "Please Enter valid Teacher Id";
	}

	@Override
	public List<Teacher> findAll() {
		return tdao.findAll();
	}
	@Override	
	public Teacher findById(int id) {
		Optional<Teacher> findById = tdao.findById(id);
		if(findById.isPresent()) {
			Teacher teacher = findById.get();
			return teacher;
		}
		return null;
		
		
	}

}
