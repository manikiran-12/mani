package com.app.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.demo.models.Teacher;
import com.app.demo.service.TeacherService;

@RestController
public class TeacherController {
	@Autowired
	private TeacherService service;
	
	@PostMapping("/addteacher")
	public String addTeacher(@RequestBody Teacher teacher) {
		 service.addTeacher(teacher);
		 return "Teacher Added SuccessFully";
		
	}
	@PostMapping("/teacherById")
	public String deletTecherById(int id) {
		return service.deleteTeacher(id);
	}
	@GetMapping("/getteachers")
	public List<Teacher> findAll() {
		return service.findAll();
		
		 
		
	}
}
