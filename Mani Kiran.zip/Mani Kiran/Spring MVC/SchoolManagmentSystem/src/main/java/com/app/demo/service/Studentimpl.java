package com.app.demo.service;

import java.util.List;
import java.util.Optional;

import javax.mail.MessagingException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.demo.dao.AdminDao;
import com.app.demo.dao.StudentDao;
import com.app.demo.models.Admin;
import com.app.demo.models.Student;
import com.app.demo.utils.MailService;

@Service
@PropertySource("classpath:logger.properties")
public class Studentimpl implements Studentservice {

	private static Logger log = Logger.getLogger(Studentimpl.class);
	@Autowired
	private StudentDao dao;
	@Autowired
	private MailService mail;

	@Autowired
	private AdminDao admindao;

	@Autowired
	private PasswordEncoder pass;

	@Override
	public void addStudent(Student student) {
		student.setPassword(pass.encode(student.getPassword()));
		dao.save(student);
		log.debug("success");

	}

	@Override
	public String deleteStudent(int id) {
		System.out.println(dao.existsById(id));

		if (dao.existsById(id)) {
			dao.deleteById(id);
			return "Deleted user";
		} else {
			return "Please Enter valid user";
		}
	}

	@Override
	public List<Student> findAll() {
		List<Student> list = dao.findAll();
		return list;

	}

	@Override
	public Student findById(int id) throws Exception {

		/*
		 * Layout layout = new PatternLayout("%d [%c] (%l) %p %m %n"); Appender appender
		 * = new FileAppender(layout, "D:/logger/school.log");
		 * log.addAppender(appender);
		 */
		/*
		 * PropertyConfigurator.configure(logger.properties);
		 * System.getProperty("logger.properties");
		 */


		Optional<Student> optional = dao.findById(id);

//		String email=optional.get().getEmail();
		if (optional.isPresent()) {
			Student student2 = optional.get();
			try {
				mail.sendEmail(student2);
				log.debug("Success");

				Admin admin = admindao.findAll().get(0);
				mail.sendEmail(admin, student2);

			} catch (MessagingException e) {

				log.info(e);
			}

			return student2;

		}
		return null;
	}

	public Student updateById(Student student2) {
		Optional<Student> optional = dao.findById(student2.getSid());
		if (optional.isPresent()) {

			return dao.save(student2);
		}

		return null;
	}

}
