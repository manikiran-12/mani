package com.app.demo.controller;

import java.util.List;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.demo.models.Admin;
import com.app.demo.models.Student;
import com.app.demo.service.Studentimpl;
import com.app.demo.utils.MailService;

@RestController
public class StudentController {
	@Autowired
	private Studentimpl userservice;


	@PostMapping("/addstudent")
	public String adduser(@RequestBody Student student) {

		userservice.addStudent(student);
		return "Student Added Successfully";
	}

	@PostMapping("/deletestudent")
	public String deleteById(@RequestParam int id) {
		return userservice.deleteStudent(id);

	}

	@GetMapping("/studentlist")
	public List<Student> findAll() {
		return userservice.findAll();
	}

	@GetMapping("/findbyid")
	public Student findById(@RequestParam int id) throws Exception {
	
		

		return userservice.findById(id);
	}

	@PutMapping("/updateid")
	public Student updateById(@RequestBody Student student) {
		return userservice.updateById(student);
	}

}
