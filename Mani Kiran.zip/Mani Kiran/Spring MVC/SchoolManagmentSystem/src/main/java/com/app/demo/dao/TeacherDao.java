package com.app.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.app.demo.models.Teacher;

@Repository
@EnableJpaRepositories
public interface TeacherDao extends JpaRepository<Teacher, Integer> {

	

}
