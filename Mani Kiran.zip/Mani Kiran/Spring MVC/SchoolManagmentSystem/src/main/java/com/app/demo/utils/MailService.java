package com.app.demo.utils;

import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import com.app.demo.dao.AdminDao;
import com.app.demo.models.Admin;
import com.app.demo.models.Student;

@Component
public class MailService {

	@Autowired
	private JavaMailSender javaMailSender;
	@Autowired
	private Student student;
	@Autowired
	private AdminDao adminDao;
	
	
	public void sendEmail(Student student) throws MessagingException {

		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setTo(student.getEmail());
		mailMessage.setText("You are successfully Logged-in");

		mailMessage.setSubject("School Managment System");
		javaMailSender.send(mailMessage);

	}
	public void sendEmail(Admin admin,Student student) {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setTo(admin.getEmail());
		mailMessage.setText("You are successfully Logged-in");
		mailMessage.setText("Loggined with id : "+student.getSid() + " and Email Id : " + student.getEmail());

		mailMessage.setSubject("School Managment System");
		javaMailSender.send(mailMessage);

	}


	

}
