package com.app.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.demo.dao.AdminDao;
import com.app.demo.dao.StudentDao;
import com.app.demo.models.Admin;
import com.app.demo.models.Student;
import com.app.demo.models.Teacher;
import com.app.demo.service.Studentimpl;
import com.app.demo.service.TeacherService;
import com.app.demo.utils.MailService;

@RestController
public class AdminController {

	@Autowired
	private Studentimpl studentservice;
	@Autowired
	private TeacherService teacherservice;
	@Autowired
	private StudentDao studentdao;
	@Autowired
	private AdminDao admindao;
	@Autowired
	private MailService mail;
	@Autowired
	private PasswordEncoder passwordEncoder;

	@GetMapping("/login")
	public Object login(@RequestParam int id, @RequestParam String password, @RequestParam String role) {
		if (role.equalsIgnoreCase("student")) {
			Optional<Student> optional = studentdao.findById(id);

			System.out.println(optional.get().getPassword());

			try {

				boolean matches = passwordEncoder.matches(password, optional.get().getPassword());

				if (optional.get().getSid() == id && matches) {
					System.out.println("hello");
					return studentservice.findById(id);

				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		else if (role.equalsIgnoreCase("teacher")) {
			Teacher optional = teacherservice.findById(id);

			try {
				boolean matches = passwordEncoder.matches(password, optional.getPassword());
				if (optional.getTid() == id && matches) {
					return teacherservice.findById(id);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (role.equalsIgnoreCase("admin")) {
			Optional<Admin> optional = admindao.findById(id);
			boolean matches = passwordEncoder.matches(password, optional.get().getPassword());
			if (optional.get().getId() == id && matches) {
				return "success";
			}

		}
		return new String("Id are Password is incorrect");

	}
}
