package com.app.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolManagmentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolManagmentSystemApplication.class, args);
		org.apache.log4j.BasicConfigurator.configure();
	
	}

}
