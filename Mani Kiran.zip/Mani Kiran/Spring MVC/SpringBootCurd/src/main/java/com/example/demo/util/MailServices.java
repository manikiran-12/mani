package com.example.demo.util;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.example.demo.model.Employee;

@Component
public class MailServices {
	@Autowired
	private JavaMailSender javaMailSender;

	public void sendEmail(Employee employee) throws MessagingException {
		System.out.println("mail class");
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
//		helper.setFrom("manikiranchary402@gmail.com");
		helper.setTo(employee.getEmail());
		helper.setSubject("Employee Project");
		helper.setText("Employee Registered successfully");
		
		javaMailSender.send(mimeMessage);

	}

}
