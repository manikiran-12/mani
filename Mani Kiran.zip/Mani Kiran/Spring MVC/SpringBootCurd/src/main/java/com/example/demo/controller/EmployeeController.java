package com.example.demo.controller;

import java.util.List;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;
import com.example.demo.util.MailServices;

@RestController
@RequestMapping(value = "/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService service;
	@Autowired
	private MailServices mail;
	
	@PostMapping(value = "/add")
	public String add(@RequestBody Employee employee) {
	
		System.out.println("hello");
		service.add(employee);
		try {
			mail.sendEmail(employee);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
       return "success";
	}
	@GetMapping("/get")
	
	public List<Employee> listAll() {
		return service.listAll();
	}
	@DeleteMapping("/delete")
	public String deleteById(@RequestParam("empid") Integer id) {
	
		service.deleteById(id);
		return "deleted";
	}
}
