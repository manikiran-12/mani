package com.user.dao;

import com.user.model.User;

public interface Userdao {

	public void addUser(User user);
}
