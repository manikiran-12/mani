package com.user.service;

import com.user.model.User;

public interface Userservice {
	
	public void addUser(User user);

}
