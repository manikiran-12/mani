package com.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.user.model.User;
import com.user.service.Userservice;
import com.user.serviceImpl.UserserviceImpl;

@Controller
public class UserController {
	@Autowired
	private Userservice service;

	@RequestMapping(value = "/")
	public String home() {
		return "home";
	}

	@RequestMapping(value = "/register")
	public String register(Model model) {
		model.addAttribute("msg","Registration Page");
		model.addAttribute("user", new User());

		return "register";

	}

	@RequestMapping(value = "/success")
	public String success(@ModelAttribute("user") User user) {
		System.out.println(user.getEmail());
		service.addUser(user);
		return "success";
	}

}
