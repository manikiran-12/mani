package com.user.daoImpl;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.user.dao.Userdao;
import com.user.model.User;

@Repository
@org.springframework.transaction.annotation.Transactional

public class Userdaoimpl implements Userdao {
	@Autowired
	private SessionFactory factory;

	public void addUser(User user) {

//	factory.getCurrentSession().save(user);
		
		Session session = factory.openSession();
		Transaction beginTransaction = session.beginTransaction();
		Serializable save = session.save(user);
		beginTransaction.commit();
		session.close();
		

	}

}
