package com.user.serviceImpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.dao.Userdao;
import com.user.model.User;
import com.user.service.Userservice;

@Service
public class UserserviceImpl implements Userservice {
	@Autowired
	private Userdao userdao;

@org.springframework.transaction.annotation.Transactional
	public void addUser(User user) {
		userdao.addUser(user);

	}

}
