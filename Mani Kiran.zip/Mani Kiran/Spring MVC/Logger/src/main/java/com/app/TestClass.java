package com.app;

import java.io.IOException;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

public class TestClass {
	private static Logger log = Logger.getLogger(TestClass.class);

	public static void main(String[] args) throws Exception {

		Layout layout = new PatternLayout("%d [%c] (%l) %p %n");
		Appender appender = new FileAppender(layout, "D:/logger/two.log");
		log.addAppender(appender);

		log.debug("hello");
		log.info("INFO");
		log.warn("WARN");
		log.error("ERROR");
		log.fatal("FATAL");
	}

	// public static void main(String[] args) throws IOException {
//		// Layout layout = new SimpleLayout();
//		// Layout layout=new HTMLLayout();
//		//Layout layout = new XMLLayout();
//		Layout layout = new PatternLayout("%p %d %c %M %m %n");
//		//Appender appender = new ConsoleAppender(layout);
//		Appender appender = new FileAppender(layout, "D:\\mylogges/data.log");
//
//		log.addAppender(appender);
//
//		log.debug("This is debug");
//		log.info("this is info");
//		log.error("this is error");
//		log.warn("this is warn");
//		log.fatal("this is fatal");
//
//	}

}
