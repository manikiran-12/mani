package com.employee.dao;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDao {
	
	public void addEmployee() {
		
	}

}
