package com.employee.model;

public class Employee {

	private String empname;
	private String email;

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Employee(String empname, String email) {
		super();
		this.empname = empname;
		this.email = email;
	}

}
