package com.employee.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.employee.model.Employee;
import com.employee.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService service;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		return "home";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView addEmployee(@RequestParam Map<String, String> map,Model model ) {
		model.addAttribute("msg", "This is Save Page");
		String empname = map.get("empname");
		String email = map.get("email");
		Employee employee = new Employee(empname, email);
		service.addEmployee(employee);

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("savepage");
		modelAndView.addObject("save", "Employee name : " + empname + ", Email : " + email);

		return modelAndView;
	}
}
