package com.employee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.dao.EmployeeDao;
import com.employee.model.Employee;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeDao dao;

	public void addEmployee(Employee employee) {
		dao.addEmployee();
	}
}
