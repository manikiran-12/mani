package com.path.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(method = RequestMethod.GET,value = "/students")
public class Student {

	@RequestMapping(value = "/student/{studentname}/{age}")
	public ModelAndView userdata(@PathVariable("studentname") String studentname,@PathVariable("age") Integer age) {
		return new ModelAndView("student", "studentmsg", "Hello, "+studentname+" you are "+age+" old");
		
	}
}
