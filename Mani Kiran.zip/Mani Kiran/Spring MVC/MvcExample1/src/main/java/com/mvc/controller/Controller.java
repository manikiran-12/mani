package com.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mvc.service.WelcomeService;

@org.springframework.stereotype.Controller
public class Controller {

	@Autowired
	private WelcomeService service;

	@RequestMapping(value = "/")
	public ModelAndView welcome() {
		return new ModelAndView("welcomepage", "welcomemsg", service.welcomemsg());
	}

	@RequestMapping(value = "welcome")
	public ModelAndView welcomeAgainmsg() {
		return new ModelAndView("welcomepage1", "welcomemsg1", service.welcomeAgain());
	}

}
