package com.mvc.service;

@org.springframework.stereotype.Service
public class WelcomeService {
	
	public String welcomemsg() {
		return "This is welcome Page";
	}

	public String welcomeAgain() {
		return "This is welcome again page";
		
	}
}
