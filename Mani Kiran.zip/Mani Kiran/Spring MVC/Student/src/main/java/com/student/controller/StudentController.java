package com.student.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.student.model.Status;
import com.student.model.Student;

@RestController
public class StudentController {

	private final static String sharedkey = "hello";
	private final static String success = "success";
	private final static int successcode = 200;
	private final static String Errorr = "Errorr";
	private final static int Errorcode = 100;

	@RequestMapping(method = RequestMethod.POST,value = "/add")
	public Status add(@RequestParam("key") String key, @RequestBody Student student) {
		Status response = new Status();
		if (sharedkey.equalsIgnoreCase(key)) {
			int sid = student.getSid();
			String sname = student.getSname();
			String email = student.getEmail();
			System.out.println(sid + " " + sname + " " + email);
			response.setStatus(success);
			response.setCode(successcode);

		} else {
			response.setStatus(Errorr);
			response.setCode(Errorcode);
		}
		return response;

	}
}
