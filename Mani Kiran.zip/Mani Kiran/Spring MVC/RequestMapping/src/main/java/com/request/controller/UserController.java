package com.request.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.request.mode.User;

@Controller
public class UserController {

	@RequestMapping(value = "/")
	public String register() {
		return "register";
	}

	@RequestMapping(value = "/registersuccess")
	public ModelAndView registersuccess(@RequestParam Map<String, String> map) {
		String username = map.get("username");
		int age = Integer.parseInt(map.get("age"));
		String email = map.get("email");
		User user = new User(username, age, email);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("user", user);
		modelAndView.setViewName("registersuccess");
		return modelAndView;
	}
}
